import numpy as np
import pandas as pd
import torch

from torch.utils.data import Dataset, DataLoader

def train_valid_indices(data, train_size=0.9, shuffle=True, random_seed=0):
    length = len(data)
    indices = list(range(0, length))

    if shuffle:
        np.random.seed(random_seed)
        np.random.shuffle(indices)

    if type(train_size) is float:
        split = int(np.floor(train_size * length))
    elif type(train_size) is int:
        split = train_size
    else:
        raise ValueError('%s should be an int or float'.format(str))
    return indices[:split],indices[split:]




class GetTrainTestData(Dataset):
    def __init__(self,input_len,output_len,train_rate,input_data,is_train = True):
        super().__init__()
        # self.input_data = input_data
        self.x=input_data
        self.sample_num=len(self.x)
        self.input_len=input_len
        self.output_len=output_len
        self.train_rate=train_rate
        self.src,self.trg=[],[]
        if is_train:
            for i in range(int(self.sample_num * train_rate)-self.input_len-self.output_len+1):
                self.src.append(self.x[i:(i + input_len)])
                self.trg.append(self.x[(i + input_len):(i + input_len + output_len)])

        else:
            for i in range(int(self.sample_num * train_rate), self.sample_num-self.input_len-self.output_len,output_len):
                self.src.append(self.x[i:(i + input_len)])
                self.trg.append(self.x[(i + input_len):(i + input_len + output_len)])
        # print(len(self.src),len(self.trg))

    def __getitem__(self,index):
        return self.src[index], self.trg[index]

    def __len__(self):
        return len(self.src) #  或者return len(self.trg), src和trg长度一样


def split_train_valid(input_len,output_len,input_data):
    train = []
    label = []

    data_length = len(input_data)
    for i in range(data_length-input_len-output_len+1):
        train.append(input_data[i:i+input_len])
        label.append(input_data[(i + input_len):(i + input_len + output_len)])
    train_valid = list(zip(train,label))

    return train_valid



def get_data(m,l,batch_size):
    tensors = []
    for time in range(1488-batch_size):
        matrix_logs=l[time][:].reshape((100,100))
        # matrix_logs = np.arange(1, 10001, 1).reshape((100, 100))
        lis = []
        for i in range(m,100+m,m):#先取行
            for j in range(m,100+m,m):#在取列
                mat = matrix_logs[i-m:i,j-m:j]
                lis.append(mat)
        tensors.append(lis)

    tensors = np.array(tensors[:])#测试时候使用，只取前40个小方阵，同时取费时间
    tensors = torch.from_numpy(tensors).type(torch.FloatTensor)
    return tensors





def data_restore(input_mat,side_length):
    block = int(10000 / (side_length ** 2))
    time_dim = input_mat.shape[0]
    # input_mat = input_mat.permute(1,0,2).view(time_dim,block,side_length,side_length)
    input_mat = input_mat.view(time_dim,block,side_length,side_length)

    data = []
    for n in range(time_dim):
        mat = input_mat[n, :, :, :].squeeze(0)
        lis = []
        for m in np.arange(0, block).reshape(int(100 / side_length), int(100 / side_length)):
            for j in range(side_length):
                for i in m:
                    lis.append(mat[i][j][:])
        # n = np.concatenate(([lis[i] for i in range(len(lis))]), axis=0)
        data.append(np.concatenate(([lis[i] for i in range(len(lis))]), axis=0))

    return np.array(data)
