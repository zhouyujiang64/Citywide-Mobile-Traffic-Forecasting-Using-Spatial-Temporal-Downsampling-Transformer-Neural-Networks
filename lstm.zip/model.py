import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler(feature_range=(0, 1))
from  torch.nn import init
from  dataloader import GetTrainTestData
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader, TensorDataset
import parameter as my_data

input_len = my_data.input_len
output_len = my_data.output_len
embed_size = my_data.embed_size
application = my_data.application
batch_size = my_data.batch_size
num_encoder_layers = my_data.num_encoder_layers

class LSTMModel(nn.Module):
    """Container module with an encoder, a recurrent module, and a decoder."""

    def __init__(self, input_size, hidden_size, nlayers, dropout=0.5):
        super(LSTMModel, self).__init__()
        self.drop = nn.Dropout(dropout)

        self.rnn = nn.LSTM(input_size, hidden_size, nlayers, dropout=dropout,batch_first=True,bidirectional=True)
        self.decoder = nn.Linear(hidden_size*2, input_size)
        self.init_weights()
        self.sigmod = nn.Sigmoid()

    def init_weights(self):
        initrange = 0.1
        self.decoder.bias.data.zero_()
        self.decoder.weight.data.uniform_(-initrange, initrange)

    def forward(self, input):


        output, _ = self.rnn(input, None)

        out = output[:,-1,:].unsqueeze(1)

        out = self.decoder(out)


        return self.sigmod(out.view(batch_size,output_len,10000))

    def init_hidden(self, bsz):
        weight = next(self.parameters())
        return (weight.new_zeros(self.nlayers*2, bsz, self.nhid),
                weight.new_zeros(self.nlayers*2, bsz, self.nhid))

def repackage_hidden(h):
    if isinstance(h, torch.Tensor):
    #isinstance() 函数来判断一个对象是否是一个已知的类型
        return h.detach()
    # 这个是GRU的截断，因为只有一个隐藏层，判断h是不是torch.Tensor，我没有用GRU，只用了LSTM
    else:
        return tuple(repackage_hidden(v) for v in h)
    # 这个是LSTM的截断，有两个隐藏层，格式是元组，







# if __name__ == "__main__":
#     src = np.random.random((5,4,100))
#     tar = np.random.random((5,4,100))
#     src = torch.from_numpy(src).type(torch.FloatTensor).to('cuda:0')
#     tar = torch.from_numpy(tar).type(torch.FloatTensor).to('cuda:0')
#
#     hidden = model.init_hidden(4)
#     # model = LSTMModel(4, 10, 10, 2,2).to('cuda:0')
#     out = model.forward(src,hidden)
#     print(out[0].shape)
