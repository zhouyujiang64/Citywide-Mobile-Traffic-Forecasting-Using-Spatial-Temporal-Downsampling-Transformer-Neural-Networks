import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import torch
import torch.nn as nn

from dataloader import *
import numpy as np
import matplotlib.pyplot as plt
import datetime
import time
import parameter as my_data
from model import LSTMModel
import os
os.environ["CUDA_VISIBLE_DEVICES"] = my_data.gpu_id


from torch.utils.data import Dataset, DataLoader, TensorDataset

import parameter as my_data
index = torch.tensor([21,  8, 11, 23, 22, 12, 17, 10, 13, 20, 16,  3,  5, 19, 14,  0, 18,  2, 15,  4,  6,  7,  9,  1])

test_data = my_data.test_data

input_len = my_data.input_len
output_len = my_data.output_len
embed_size = my_data.embed_size
application = my_data.application
scaler = my_data.scaler
heads = my_data.heads
batch_size = my_data.batch_size
device = my_data.device
num_encoder_layers = my_data.num_encoder_layers
num_decoder_layers = my_data.num_decoder_layers


model = LSTMModel(input_size = 10000,hidden_size = embed_size,nlayers = 2,)

if torch.cuda.device_count() > 1:
    print("Let's use", torch.cuda.device_count(), "GPUs!")
    # dim = 0 [30, xxx] -> [10, ...], [10, ...], [10, ...] on 3 GPUs
    model = nn.DataParallel(model)
model.to(device)

data_loader_test = DataLoader(test_data, batch_size=batch_size, shuffle=False,drop_last=True)



def predict(model):
    pre_app = []
    real_app = []
    # pre_app = np.zeros(shape=(293, output_T_dim, 10000))
    # real_app = np.zeros(shape=(293, output_T_dim, 10000))
    model.eval()
    with torch.no_grad():
        # hidden = model.init_hidden(batch_size)

        for t, eval_data in enumerate(data_loader_test):

            xx = eval_data[0]
            yy = eval_data[1].to("cpu")
            # xx = xx.permute(1, 0, 2)
            # yy = yy.permute(1, 0, 2).to('cpu')


            xxx = xx[:,index,:]
            prediction = model(xxx)

            prediction = prediction.to("cpu")


            prediction = np.array(prediction)
            yy = np.array(yy)

            pre_app.extend(prediction)
            real_app.extend(yy)



    pre_app = np.array(pre_app).reshape(-1,10000)
    real_app = np.array(real_app).reshape(-1,10000)

    # zero = np.zeros((1214,25))
    # zero_last = np.zeros((2,25))
    #
    #
    # pre_app = np.concatenate((zero,pre_app,zero_last),axis=0)
    # real_app = np.concatenate((zero,real_app,zero_last),axis=0)

    pre_app = scaler.inverse_transform(pre_app)
    real_app = scaler.inverse_transform(real_app)

    # pre_app = pre_app[1214:-2,:]
    # real_app = real_app[1214:-2,:]

    return pre_app, real_app
def calculate_loss(pre,real):
    pre = np.array(pre)
    real = np.array(real)
    pre = pre.reshape(-1, 10000)

    real = real.reshape(-1, 10000)

    MAE_loss = MAE(pre,real)

    RMSE_loss = RMSE(pre,real)
    # R2 = R2(pre,real)

    print('MAE  LOSS:',MAE_loss)
    print('RMSE  LOSS:',RMSE_loss)
    # print('R23:',R2)

    # result = "H:/data/result/828.txt"
    # with open(result, "a") as file:
    #
    #     # file.write(format('Application',"<25")+format('RMSE',"<25")+format('MAE',"<25")+format('Side',"<25")+"\n")
    #     file.write(format(application,"<25")+format('%.4f' %RMSE_loss,"<25")+format('%.4f' %MAE_loss,"<25")+format('%.4f' %side_length,"<25")+"\n")

    # df.to_csv('H:/data/result/new_result.csv', mode='a', header=True,index=False)

def MAE(pre, real):
    error = np.abs(pre - real)
    mean = np.mean(error)
    return mean

def RMSE(pre, real):
    error = np.square((pre - real))
    mean = np.mean(error)
    loss = np.sqrt(mean)

    return loss
def R2(pre,real):

    from sklearn import metrics
    real = real.transpose(1, 0)
    pre = pre.transpose(1, 0)

    return metrics.r2_score(real, pre)


def generate_csv(pre,real):


    pre_sms = np.array(pre)
    real_sms = np.array(real)

    pre_history = pd.DataFrame(pre_sms)
    real_history = pd.DataFrame(real_sms)
    pre_history.to_csv('/home/cnic-lsh/zyj/result/lstm/In:{input_length}_Out:{output_length}_lstm_pre_data.csv'.format(input_length = input_len,output_length = output_len), index=False, header=False)
    real_history.to_csv('/home/cnic-lsh/zyj/result/lstm/In:{input_length}_Out:{output_length}_lstm_real_data.csv'.format(input_length = input_len,output_length = output_len), index=False, header=False)

if __name__ == "__main__":

    model.load_state_dict(torch.load('result of model/'+application+'-In:{input_length}-Out:{out_length}-Embed_size:{embeding_size}.pth'.format( input_length = input_len,out_length = output_len,embeding_size = embed_size)))
    pre_call, real_call = predict(model)
    calculate_loss(pre_call,real_call)
    generate_csv(pre_call, real_call)