import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler(feature_range=(0, 1))
from  torch.nn import init
from  dataloader import GetTrainTestData
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader, TensorDataset


class LSTMModel(nn.Module):
    """Container module with an encoder, a recurrent module, and a decoder."""

    def __init__(self, ninp, nhid, nlayers, dropout=0.5):
        super(LSTMModel, self).__init__()
        self.drop = nn.Dropout(dropout)
        # self.encoder = nn.Embedding(ntoken, ninp)
        self.rnn = nn.LSTM(ninp, nhid, nlayers, dropout=dropout)
        self.decoder = nn.Linear(nhid, ninp)

        self.init_weights()

        self.nhid = nhid
        self.nlayers = nlayers

    def init_weights(self):
        initrange = 0.1
        # self.encoder.weight.data.uniform_(-initrange, initrange)
        self.decoder.bias.data.zero_()
        self.decoder.weight.data.uniform_(-initrange, initrange)

    def forward(self, input, hidden):
        # emb = self.drop(self.encoder(input))
        output, hidden = self.rnn(input, hidden)
        output = self.drop(output)
        decoded = self.decoder(output)
        return decoded, hidden

    def init_hidden(self, bsz):
        weight = next(self.parameters())
        return (weight.new_zeros(self.nlayers, bsz, self.nhid),
                weight.new_zeros(self.nlayers, bsz, self.nhid))



model = LSTMModel(
    ninp = 100,
    nhid = 256,
    nlayers = 5,
).to('cuda:0')


# 定义损失函数和优化函数
optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 5, gamma=0.5)
criterion = nn.MSELoss()

#
# if __name__ == "__main__":
#     src = np.random.random((5,4,100))
#     tar = np.random.random((5,4,100))
#     src = torch.from_numpy(src).type(torch.FloatTensor).to('cuda:0')
#     tar = torch.from_numpy(tar).type(torch.FloatTensor).to('cuda:0')
#
#     hidden = model.init_hidden(4)
#     # model = LSTMModel(4, 10, 10, 2,2).to('cuda:0')
#     out = model.forward(src,hidden)
#     print(out[0].shape)
