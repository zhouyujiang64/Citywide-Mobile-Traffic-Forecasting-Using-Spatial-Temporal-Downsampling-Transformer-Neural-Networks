import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import torch
import torch.nn as nn
from dataloader import GetTrainTestData, train_valid_indices
from torch.utils.data.sampler import SubsetRandomSampler
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import datetime
import time
from model import LSTMModel
import random
from torch.utils.data import Dataset, DataLoader, TensorDataset
import parameter as my_data
import os
index = torch.tensor([21,  8, 11, 23, 22, 12, 17, 10, 13, 20, 16,  3,  5, 19, 14,  0, 18,  2, 15,  4,  6,  7,  9,  1])

os.environ["CUDA_VISIBLE_DEVICES"] = my_data.gpu_id
from torch.optim.lr_scheduler import CosineAnnealingLR, CosineAnnealingWarmRestarts, StepLR

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

train_data = my_data.train_data
test_data = my_data.test_data
train_and_valid= my_data.train_and_valid

lr = my_data.lr
input_len = my_data.input_len
output_len = my_data.output_len
side_length = my_data.side_length
embed_size = my_data.embed_size
heads = my_data.heads
application = my_data.application
batch_size = my_data.batch_size
num_encoder_layers = my_data.num_encoder_layers
num_decoder_layers = my_data.num_decoder_layers



seed = 6552
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)



train_idx, valid_idx = train_valid_indices(train_and_valid, train_size=0.9, shuffle=True, random_seed=seed)
train_sampler = list(SubsetRandomSampler(train_idx))
valid_sampler = list(SubsetRandomSampler(valid_idx))

# data_train = GetTrainTestData(input_len=input_len, output_len=output_len, train_rate=0.9, input_data=train_data,is_train = True)
# data_value = GetTrainTestData(input_len=input_len, output_len=output_len, train_rate=0.9, input_data=train_data,is_train = True)

data_loader_train = DataLoader(train_and_valid, batch_size=batch_size, sampler=train_sampler,drop_last=True)
data_loader_value = DataLoader(train_and_valid, batch_size=batch_size, sampler=valid_sampler,drop_last=True)


model = LSTMModel(input_size = 10000,hidden_size = embed_size,nlayers = 2,)


if torch.cuda.device_count() > 1:
    print("Let's use", torch.cuda.device_count(), "GPUs!")
    # dim = 0 [30, xxx] -> [10, ...], [10, ...], [10, ...] on 3 GPUs
    model = nn.DataParallel(model)
model.to(device)
model = model.to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=lr)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 5, gamma=0.5)
criterion = nn.MSELoss()


# scheduler = CosineAnnealingWarmRestarts(optimizer,T_0=6,T_mult=1)


def train():
    model.train()
    total_loss = 0.
    # hidden = model.init_hidden(batch_size)
    for t, batch in enumerate(data_loader_train):
        start_time = time.time()

        x = batch[0]
        y = batch[1]
        xx = x[:,index,:]
        out = model(xx)
        loss = criterion(out, y)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        elapsed = time.time() - start_time
        if t % 20 == 0:
            print('| epoch {:d} | batches  {:d}  |loss {:.7f} |time:{:5.2f}ms|lr:{:5.7f}'.format(epoch, t, loss.item(),
                                                                                                 elapsed * 1000,
                                                                                                 optimizer.param_groups[
                                                                                                     0]['lr']))
    loss = total_loss / len(data_loader_train)

    return loss


def evaluate(eval_model):
    eval_model.eval()
    total_loss = 0.
    # hidden = model.init_hidden(batch_size)

    with torch.no_grad():
        for t, eval_data in enumerate(data_loader_value):
            xx = eval_data[0]
            yy = eval_data[1]
            xxx = xx[:,index,:]
            out = model(xxx)
            loss = criterion(out, yy)
            total_loss += loss.item()
        loss = total_loss / len(data_loader_value)
    return loss


def plot_metric(dfhistory, metric):
    train_metrics = dfhistory[metric]
    val_metrics = dfhistory['val_' + metric]
    epochs = range(1, len(train_metrics) + 1)
    plt.plot(epochs, train_metrics, color="blue")
    plt.plot(epochs, val_metrics, color="red")
    plt.title('Training and validation ' + metric)
    plt.xlabel("Epochs")
    plt.ylabel(metric)
    plt.legend(["train_" + metric, 'val_' + metric])

    # plt.savefig('Inputday:{Inputday}-Outputday:{Outputday}-Head:{Head}-Length{Length}-Embed{Embed}.jpg'.format(Inputday = T_dim,Outputday = output_T_dim,Head = heads,Length = side_length,Embed = embed_size))
    plt.savefig('result of loss/' + application + '-In:{input_length}-Out:{out_length}-Embed_size:{embeding_size}.jpg'.format( input_length = input_len,out_length = output_len,embeding_size = embed_size))

    plt.show()


if __name__ == "__main__":
    print("Start Training...")
    dfhistory = pd.DataFrame(columns=["epoch", "loss", "val_loss", 'time'])

    start_time = datetime.datetime.now()
    min_loss = 1.
    min_epoch = 1
    epochs = 100
    pltyy = []
    plty = []

    for epoch in range(1, epochs + 1):
        epochs_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print("========" * 3 + "%s" % epochs_time + "========" * 3)
        epochs_time = datetime.datetime.now()
        loss = train()
        scheduler.step()

        val_loss = evaluate(model)

        if val_loss < min_loss:
            min_loss = val_loss
            min_epoch = epoch
            print("Saveing model...")
            torch.save(model.state_dict(),
                       "result of model/" + application + '-In:{input_length}-Out:{out_length}-Embed_size:{embeding_size}.pth'.format( input_length = input_len,out_length = output_len,embeding_size = embed_size))
        epoch_time = datetime.datetime.now()
        consume_time = str(epoch_time - epochs_time)
        info = (epoch, loss, val_loss, consume_time)
        dfhistory.loc[epoch - 1] = info
        print(("| EPOCH = %d| " + " LOSS = %.5f| " + " VAL_LOSS = %.5f | " + "consume_time = %s|") % info)
        print("The min epoch is:" + "%d" % min_epoch)

        plot_metric(dfhistory, "loss")
        if epoch % 20 == 0:
            dfhistory.to_csv(
                'result of loss/' + application + '-In:{input_length}-Out:{out_length}-Embed_size:{embeding_size}.csv'.format( input_length = input_len,out_length = output_len,embeding_size = embed_size))

    last_time = datetime.datetime.now()
    print("The training has been consumed:" + "%s" % str(last_time - start_time))

    print(dfhistory)
    print('Finished Training...')
    # dfhistory.to_csv('result of loss/' + application + 'Output{Outputday}-Embed{Embed}.csv'.format(
    #     Outputday=output_len, Embed=embed_size))












