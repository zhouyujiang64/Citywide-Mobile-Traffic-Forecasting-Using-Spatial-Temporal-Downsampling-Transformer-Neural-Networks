
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
import math
import parameter as my_data

import numpy as np
import copy
input_len = my_data.input_len
output_len = my_data.output_len
side_length = my_data.side_length
embed_size = my_data.embed_size

heads  = my_data.heads

batch_size = my_data.batch_size
device = my_data.device


class MLP(nn.Module):
    def __init__(self,featrue_size,hidden_size = [512,1024],dropout = 0.5):
        super(MLP, self).__init__()
        self.linear_1 = nn.Linear(featrue_size,hidden_size[0])
        self.linear_2 = nn.Linear(hidden_size[0],hidden_size[1])
        self.linear_3 = nn.Linear(hidden_size[1],featrue_size)
        self.linear_4 = nn.Linear(input_len,1)

        self.drop = nn.Dropout(dropout)
        self.sigmod = nn.Sigmoid()
        self.conv = nn.Conv2d(input_len*2,output_len,kernel_size=3,padding=1)

        self.init_weights()
    def init_weights(self):
        initrange = 0.1
        # self.encoder.weight.data.uniform_(-initrange, initrange)
        self.linear_1.bias.data.zero_()
        self.linear_1.weight.data.uniform_(-initrange, initrange)
        self.linear_2.bias.data.zero_()
        self.linear_2.weight.data.uniform_(-initrange, initrange)
        self.linear_3.bias.data.zero_()
        self.linear_3.weight.data.uniform_(-initrange, initrange)

    def forward(self,input):
       out = self.drop(self.linear_1(input))
       out = self.sigmod(out)
       out = self.linear_2(out)
       out = self.sigmod(out)
       out = self.linear_3(out)
       out = out[:,-1,:].unsqueeze(1)
       # out = self.linear_4(out.permute(0,2,1))
       return self.sigmod(out)
       # return out[:,-1,:].unsqueeze(1)




def clones(module, N):
    return nn.ModuleList([copy.deepcopy(module) for _ in range(N)])