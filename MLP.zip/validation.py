import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import torch
import torch.nn as nn

from dataloader import *
import numpy as np
import matplotlib.pyplot as plt
import datetime
import time
from model import MLP

from sklearn.preprocessing import MinMaxScaler,StandardScaler


from torch.utils.data import Dataset, DataLoader, TensorDataset
# scaler = MinMaxScaler(feature_range=(0, 1))

import parameter as my_data


# train_data = my_data.train_data
test_data = my_data.test_data

input_len = my_data.input_len
output_len = my_data.output_len
embed_size = my_data.embed_size
application = my_data.application
scaler = my_data.scaler
heads = my_data.heads
batch_size = my_data.batch_size
device = my_data.device
num_encoder_layers = my_data.num_encoder_layers
num_decoder_layers = my_data.num_decoder_layers
side_length = my_data.side_length


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# data = scaler.fit_transform(input_data)

# data_mat = get_data(side_length,data,batch_size).view(1488-batch_size,int((100/side_length)**2),side_length**2).to(device)

# data = torch.cat((internet,sms,call),0).to(device).permute(1,0,2,3)

# data_test=GetTrainTestData(input_len=input_len,output_len=output_len,train_rate=0.8,input_data=test_data,is_train=False)
data_loader_test = DataLoader(test_data, batch_size=batch_size, shuffle=False,drop_last=True)

model = MLP(featrue_size=10000,hidden_size = [512,1024],dropout = 0.3).to(device)



def predict(model):
    pre_app = []
    real_app = []
    # pre_app = np.zeros(shape=(293, output_T_dim, 10000))
    # real_app = np.zeros(shape=(293, output_T_dim, 10000))
    model.eval()
    with torch.no_grad():
        for t, eval_data in enumerate(data_loader_test):

            xx = eval_data[0]
            yy = eval_data[1].to("cpu")
            # xx = xx.permute(1, 0, 2)
            # yy = yy.permute(1, 0, 2).to('cpu')



            prediction = model(xx)
            prediction = prediction.to("cpu")
            # prediction = scaler.inverse_transform(prediction).to("cpu")
            # real = scaler.inverse_transform(yy)


            # prediction = data_restore(prediction,side_length)
            # real =data_restore(yy,side_length)


            prediction = np.array(prediction)
            yy = np.array(yy)

            pre_app.extend(prediction)
            real_app.extend(yy)

    with torch.autograd.profiler.profile(enabled=True, use_cuda=True, record_shapes=False,profile_memory=False) as prof:
        outputs = model(xx)
    print(prof.table())
    prof.export_chrome_trace('result of profile/mlp_profile.json')


    pre_app = np.array(pre_app).reshape(-1,10000)
    real_app = np.array(real_app).reshape(-1,10000)

    # zero = np.zeros((1214,25))
    # zero_last = np.zeros((2,25))
    #
    #
    # pre_app = np.concatenate((zero,pre_app,zero_last),axis=0)
    # real_app = np.concatenate((zero,real_app,zero_last),axis=0)

    pre_app = scaler.inverse_transform(pre_app)
    real_app = scaler.inverse_transform(real_app)

    # pre_app = pre_app[1214:-2,:]
    # real_app = real_app[1214:-2,:]

    return pre_app, real_app




def calculate_loss(pre,real):
    pre = np.array(pre)
    real = np.array(real)
    pre = pre.reshape(-1, 10000)
    real = real.reshape(-1, 10000)

    MAE_loss = MAE(pre,real)

    RMSE_loss = RMSE(pre,real)

    print('MAE  LOSS:',MAE_loss)
    print('RMSE  LOSS:',RMSE_loss)


def MAE(pre, real):
    error = np.abs(pre - real)
    mean = np.mean(error)

    return mean

def RMSE(pre, real):
    error = np.square((pre - real))
    mean = np.mean(error)
    loss = np.sqrt(mean)

    return loss

def generate_csv(pre,real):
    # pre = pre.squeeze(1)
    # real = real.squeeze(1)
    pre_history = pd.DataFrame(pre)
    real_history = pd.DataFrame(real)
    pre_history.to_csv('/home/cnic-lsh/zyj/result/MLP/In:{input_length}_Out:{output_length}_transformer_pre_data.csv'.format(input_length = input_len,output_length = output_len), index=False, header=False)
    real_history.to_csv('/home/cnic-lsh/zyj/result/MLP/In:{input_length}_Out:{output_length}_transformer_pre_data.csv'.format(input_length = input_len,output_length = output_len), index=False, header=False)


if __name__ == "__main__":



    model.load_state_dict(torch.load('result of model/'+application+ '-In:{input_length}-Out:{out_length}.pth'.format( input_length = input_len,out_length = output_len)))

    total = sum([param.nelement() for param in model.parameters()])
    print("Number of parameters: %.2fM" % (total / 1e6))

    pre_call, real_call = predict(model)
    calculate_loss(pre_call,real_call)

    # generate_csv(pre_call,real_call)
    # for i in random_City:
    #     plot_metric(pre_call, real_call, i)
    # data_test = call.view(25,1485,400).to("cpu")
    # data_restore = data_restore(data_test,side_length)
    #
    # pre_history = pd.DataFrame(data_restore)
    # pre_history.to_csv('H:/data/new_history/1234.csv', index=False, header=False)

    # for j in random_Time:
    #     plot_timecity(output,real,j)












