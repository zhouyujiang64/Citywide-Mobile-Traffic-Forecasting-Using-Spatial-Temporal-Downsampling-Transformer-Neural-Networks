import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import torch
import torch.nn as nn

from dataloader import *
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import datetime
import time
from convolution_lstm import ConvLSTM
import parameter as my_data
from sklearn.preprocessing import MinMaxScaler,StandardScaler
from torch.utils.data import Dataset, DataLoader, TensorDataset

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
index = torch.tensor([21,  8, 11, 23, 22, 12, 17, 10, 13, 20, 16,  3,  5, 19, 14,  0, 18,  2, 15,  4,  6,  7,  9,  1])

application = my_data.application

test_data = my_data.test_data

input_len = my_data.input_len
output_len = my_data.output_len
embed_size = my_data.embed_size
application = my_data.application
scaler = my_data.scaler
heads = my_data.heads
batch_size = my_data.batch_size
device = my_data.device
num_encoder_layers = my_data.num_encoder_layers
num_decoder_layers = my_data.num_decoder_layers
side_length = my_data.side_length




data_loader_test = DataLoader(test_data, batch_size=batch_size, shuffle=False,drop_last=True)
# model = ConvLSTM(input_channels=3, hidden_channels=[128, 1], kernel_size=3, step=2,
#                  effective_step=[1]).to(device)
model = ConvLSTM(input_channels=input_len, hidden_channels=[256, output_len], kernel_size=3, step=2,
                 effective_step=[1]).to(device)


def predict(model):

    pre_app = []
    real_app = []
    model.eval()
    with torch.no_grad():
        for t, eval_data in enumerate(data_loader_test):

            xx = eval_data[0].view(batch_size,input_len,100,100)
            yy = eval_data[1].view(batch_size,output_len,100,100).to('cpu')


            prediction = model(xxx)
            prediction = prediction[0][0]
            prediction = prediction.to('cpu')

            real = np.array(yy)
            prediction = np.array(prediction)


            pre_app.extend(prediction)
            real_app.extend(real)

    # with torch.autograd.profiler.profile(enabled=True, use_cuda=True, record_shapes=False,profile_memory=False) as prof:
    #     outputs = model(xx)
    # print(prof.table())
    # prof.export_chrome_trace('result of profile/convlstm_profile.json')

    pre_app = np.array(pre_app).reshape(-1, 10000)
    real_app = np.array(real_app).reshape(-1, 10000)

    pre_app = scaler.inverse_transform(pre_app)
    real_app = scaler.inverse_transform(real_app)

    return pre_app, real_app






def calculate_loss(pre_sms,real_sms):
    pre_sms = np.array(pre_sms)
    real_sms = np.array(real_sms)
    pre = pre_sms.reshape(-1, 10000)

    real = real_sms.reshape(-1, 10000)


    MAE_loss = MAE(pre,real)

    RMSE_loss = RMSE(pre,real)

    print('MAE  LOSS:',MAE_loss)
    print('RMSE  LOSS:',RMSE_loss)


def MAE(pre, real):
    error = np.abs(pre - real)
    mean = np.mean(error)

    return mean

def RMSE(pre, real):
    error = np.square((pre - real))
    mean = np.mean(error)
    loss = np.sqrt(mean)

    return loss

def generate_csv(pre,real):


    pre_sms = np.array(pre)
    real_sms = np.array(real)

    pre_history = pd.DataFrame(pre_sms)
    real_history = pd.DataFrame(real_sms)
    pre_history.to_csv('/home/cnic-lsh/zyj/convlstm/result/'+application+'-In{input_length}-Out{out_length}-convlstm-pre.csv'.format( input_length = input_len,out_length = output_len), index=False, header=False)
    real_history.to_csv('/home/cnic-lsh/zyj/convlstm/result/'+application+'-In{input_length}-Out{out_length}-convlstm-real.csv'.format( input_length = input_len,out_length = output_len), index=False, header=False)


if __name__ == "__main__":
    model.load_state_dict(torch.load("result of model/" + application +'-In{input_length}-Out{out_length}.pth'.format( input_length = input_len,out_length = output_len)))
    # model.load_state_dict(torch.load('result of model/'+application+'side20-out1-Head10.pth'))
    total = sum([param.nelement() for param in model.parameters()])
    print("Number of parameters: %.2fM" % (total / 1e6))

    pre_call, real_call = predict(model)
    # calculate_loss(pre_call,real_call)

    # generate_csv(pre_call,real_call)
    # for i in random_City:
    #     plot_metric(pre_call, real_call, i)
    # data_test = call.view(25,1485,400).to("cpu")
    # data_restore = data_restore(data_test,side_length)
    #
    # pre_history = pd.DataFrame(data_restore)
    # pre_history.to_csv('H:/data/new_history/1234.csv', index=False, header=False)

    # for j in random_Time:
    #     plot_timecity(output,real,j)












